function myx = sort_x(xmax, xmin)
    myx = sort([xmax , xmin]);
end